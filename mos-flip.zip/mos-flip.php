<?php
/*
Plugin Name: Mos Flip
Plugin URI:
Description: Simaple shortcode
Author: Md. Mostak Shahid
Version: 1.0.0
Author URI: http://mostak.belocal.today
*/
add_shortcode('ap-barfiller','barfiller_callback');
add_action( 'vc_before_init', 'barfiler_addon_callback' );

function barfiller_callback ($atts){
	$atts = shortcode_atts(array(
		'attachment_id' => '',
		'content' => '',
	),$atts);
	ob_start();
	?>
	<div class="flip-box">
		<div class="flip-box-inner">
			<div class="flip-box-front">
				<?php $attachment_alt = get_post_meta( $atts['attachment_id'], '_wp_attachment_image_alt', true ); ?>
				<img class="img-mos" src="<?php echo wp_get_attachment_url( $atts['attachment_id'] )?>" alt="<?php echo $attachment_alt; ?>">
			</div>
			<div class="flip-box-back">
				<?php echo $atts['content'] ?>
			</div>
		</div>
	</div>


	<?php
	$output = ob_get_clean();
	return $output;
}
?>

<?php
function barfiler_addon_callback() {
	vc_map( array(
		"name" => __( "Mos Image Flip", "my-text-domain" ),
		"base" => "ap-barfiller",
		"class" => "",
		"category" => __( "Content", "my-text-domain"),
		"params" => array(
			array(
				"type" => "attach_image",
				"heading" => __( "Image", "my-text-domain" ),
				"param_name" => "attachment_id",
			),
			array(
				"type" => "textarea",
				"heading" => __( "Content", "my-text-domain" ),
				"param_name" => "content"
			),
		)
	) );
}
?>